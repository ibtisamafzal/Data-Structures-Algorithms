# Data-Structure-and-Algorithm
This is the easiest form of code for Data Structures and Algorithms using C++.
